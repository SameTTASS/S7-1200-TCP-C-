﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using S7.Net;

/// <summary>
/// samet taş
/// </summary>
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        Plc S7;


        public Form1()
        {
            InitializeComponent();
        }
        private void connect_Click(object sender, EventArgs e)
        {
            CpuType cpu = new CpuType();
            string ipAdres = ipAddress.Text;
            string comboBoxSecim = plcTipi.SelectedItem.ToString();
            short rack = Convert.ToInt16(RackCombo.SelectedItem);
            short slot = Convert.ToInt16(SlotCombo.SelectedItem);

            if (comboBoxSecim.Equals("S71500"))
            {
                cpu = CpuType.S71500;
            }
            else if (comboBoxSecim.Equals("S71200"))
            {
                cpu = CpuType.S71200;
            }

            S7 = new Plc(cpu, ipAdres, rack, slot);
            S7.Open();
            if(S7.IsConnected)
            {
                label4.Text = "Bağlantı Başarılı";
                label4.ForeColor = Color.Green;
                timer1.Start();

            }
            else
            {
                label4.Text = "Bağlı Değil";
                label4.ForeColor = Color.Red;
                timer1.Stop();
            }
        }
        private void disconnect_Click(object sender, EventArgs e)
        {
            S7.Close();
            timer1.Stop();
            label4.Text = "Bağlı Değil";
            label4.ForeColor = Color.Red;
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            S7.Close();
            timer1.Stop();
        } 
        private void Form1_Load(object sender, EventArgs e)
        {
        
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                  if (S7.IsConnected) 
                   {
                    label4.Text = "Bağlantı Başarılı";
                    label4.ForeColor = Color.Green;
                    checkBox1.ForeColor = Color.Green;
                  S7.WriteBit(DataType.Output, 0, 0, 0, true);// DB0 Q 0.0 PLC DİREK ÇIKIŞ VERİR TRUE FALSE
                }
                  else
                  {
                    label4.Text = "Bağlı Değil";
                    label4.ForeColor = Color.Red;
                    checkBox1.ForeColor = Color.Red;
                }
            }
            else if (checkBox1.Checked == false)
            {
                if (S7.IsConnected)
                {
                    label4.Text = "Bağlantı Başarılı";
                    label4.ForeColor = Color.Green;
                    checkBox1.ForeColor = Color.Green;
                    S7.WriteBit(DataType.Output, 0, 0, 0, false);
                }
                else
                {
                    label4.Text = "Bağlı Değil";
                    label4.ForeColor = Color.Red;
                    checkBox1.ForeColor = Color.Red;
                }
            }
        }

           /// <summary>
           /// /////////////////////////////////////////
           /// </summary>
        public struct DB1
        {
            public bool a;
            public short b;
            public int c;
            public double d;
        }
       
        private void button3_Click(object sender, EventArgs e)
        {
                DB1 db1 = new DB1();
            db1.a = Convert.ToBoolean(textBox1.Text);
            db1.b = Convert.ToInt16(textBox2.Text);
            db1.c = Convert.ToInt32(textBox3.Text);
            db1.d = Convert.ToSingle(textBox4.Text);
            if (S7.IsConnected)
            {
                label4.Text = "Bağlantı Başarılı";
                label4.ForeColor = Color.Green;
                S7.WriteStruct(db1, 1);
            }
            else
            {
                label4.Text = "Bağlı Değil";
                label4.ForeColor = Color.Red;
            }

        }
        /// /////////////////////////////////////////
    }
} 
